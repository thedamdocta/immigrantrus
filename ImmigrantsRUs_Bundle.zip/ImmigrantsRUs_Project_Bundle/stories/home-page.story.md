## Story: Home Page Layout
### Objective:
Build homepage with Hero, tagline, CTA, and shadcn Card or Section components.
