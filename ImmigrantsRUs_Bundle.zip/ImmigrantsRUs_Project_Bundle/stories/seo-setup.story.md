## Story: SEO Setup
### Objective:
Add structured meta tags, OpenGraph data, sitemap, and robots.txt.
