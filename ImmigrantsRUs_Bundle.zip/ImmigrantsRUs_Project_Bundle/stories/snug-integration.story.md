## Story: Snug Estate Planning Integration
### Objective:
Redirect or embed Snug dashboard for users selecting Estate Planning.
